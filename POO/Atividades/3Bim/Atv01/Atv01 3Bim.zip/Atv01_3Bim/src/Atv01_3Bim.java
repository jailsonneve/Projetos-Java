import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Atv01_3Bim extends JFrame implements ActionListener, ItemListener {
    private JLabel nameLabel, outputLabel, statusLabel;
    private JTextField nameField;
    private JButton submitButton;
    private JCheckBox emailCheckBox;
    private JComboBox<String> statusComboBox;
    private JPanel panel;

    public Atv01_3Bim() {
        // Configurações da janela principal
        setTitle("Formulário Simples");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Inicialização dos componentes
        panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1)); // Organiza os componentes em uma grade de 6 linhas
        
        nameLabel = new JLabel("Digite seu nome:");
        nameField = new JTextField(15);
        submitButton = new JButton("Enviar");
        emailCheckBox = new JCheckBox("Consentimento para receber emails");
        statusComboBox = new JComboBox<>(new String[]{"Estudante", "Professor", "Outro"});
        outputLabel = new JLabel("");
        statusLabel = new JLabel("Selecione seu status:");

        // Adiciona listeners para eventos
        nameField.addActionListener(this);
        submitButton.addActionListener(this);
        statusComboBox.addItemListener(this);

        // Adiciona componentes ao painel
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(emailCheckBox);
        panel.add(statusLabel);
        panel.add(statusComboBox);
        panel.add(submitButton);
        panel.add(outputLabel);

        // Adiciona o painel à janela
        add(panel);

        // Torna a janela visível
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            // Valida se o campo de nome não está vazio e se o checkbox foi marcado
            String name = nameField.getText();
            boolean isEmailChecked = emailCheckBox.isSelected();
            String status = (String) statusComboBox.getSelectedItem();

            if (name.isEmpty()) {
                outputLabel.setText("Erro: O nome não pode estar vazio.");
            } else if (!isEmailChecked) {
                outputLabel.setText("Erro: Você precisa consentir com o recebimento de emails.");
            } else {
                outputLabel.setText("Olá " + name + ", seu status é: " + status);
            }
        }

        if (e.getSource() == nameField) {
            // Atualiza o texto do JLabel quando algo é digitado no JTextField
            outputLabel.setText("Nome digitado: " + nameField.getText());
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == statusComboBox) {
            // Exibe o item selecionado na JComboBox no JLabel
            String selectedStatus = (String) statusComboBox.getSelectedItem();
            outputLabel.setText("Status selecionado: " + selectedStatus);
        }
    }

    public static void main(String[] args) {
        // Executa o programa
        new Atv01_3Bim();
    }
}
