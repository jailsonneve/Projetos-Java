package heranca;

public class pessoaFisica extends pessoa {
	private String rg;
	public void setRG(String rg) {
		this.rg = rg;
	}
	public String getRG() {
		return this.rg;
	}
}
