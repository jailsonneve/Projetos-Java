package heranca;

import java.util.Scanner;

public class testaPessoa {

	public static void main(String[] args) {
		Scanner batata = new Scanner(System.in);
		
		funcionario f1 = new funcionario();
		pessoaFisica pf1 = new pessoaFisica();
		pessoaJuridica pj1 = new pessoaJuridica();
		
		System.out.println("-----------------Funcionário-----------------");
		
		System.out.println("Informe o nome: ");
		f1.setNome(batata.nextLine());
		
		System.out.println("Informe o RG: ");
		f1.setRG(batata.nextLine());
		
		System.out.println("Informe o cartão: ");
		f1.setCartao(batata.nextLine());
		
		System.out.print("Nome: " + f1.getNome() + " RG: " + f1.getRG() + " Cartão: " 
				+ f1.getCartao());
		
		System.out.println("\n-----------------Pessoa Física-----------------");
		
		System.out.println("Informe o nome: ");
		pf1.setNome(batata.nextLine());
		
		System.out.println("Informe o RG: ");
		pf1.setRG(batata.nextLine());
		
		System.out.print("Nome: " + pf1.getNome() + " RG: " + pf1.getRG());
		
		System.out.println("\n-----------------Pessoa Jurídica-----------------");

		System.out.println("Informe o nome: ");
		pj1.setNome(batata.nextLine());
		
		System.out.println("Informe o CNPJ: ");
		pj1.setCNPJ(batata.nextLine());
		
		System.out.print("Nome: " + pj1.getNome() + " RG: " + pj1.getCNPJ());
		
		System.out.println("\n-----------------Cabou-----------------");
		
		batata.close();
	}

}
