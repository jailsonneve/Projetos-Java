package heranca;

public class pessoaJuridica extends pessoa {
	private String cnpj;
	public void setCNPJ(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getCNPJ() {
		return this.cnpj;
	}
}
