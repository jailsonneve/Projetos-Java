package heranca;

public class funcionario extends pessoaFisica {
	private String cartao;
	public void setCartao(String cartao) {
		this.cartao = cartao;
	}
	public String getCartao() {
		return this.cartao;
	}
}
