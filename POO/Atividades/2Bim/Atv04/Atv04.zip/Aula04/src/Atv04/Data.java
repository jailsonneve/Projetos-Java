package Atv04;

public class Data extends Tempo {
	private Integer dia;
	private Integer mes;
	private Integer ano;
	
	public void data() {
	}
	public void data(Integer dia,Integer mes,Integer ano) {
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}
	public void setDia(Integer dia) {
		this.dia = dia;
	}
	public void setMes(Integer mes) {
		this.mes = mes;
	}
	public void setAno(Integer ano) {
		this.ano = ano;
	}
	
	public Integer getDia() {
		return dia;
	}
	public Integer getMes() {
		return mes;
	}
	public Integer getAno() {
		return ano;
	}
	
	public long quantidade() {
		if (dia != null && mes != null && ano != null) {
			return (ano * 31104000 + mes * 2592000 + dia * 86400);
		} else {
			return 0;
		}
	}
	public String toString() {
		return String.format("%02d/%02d/%04d", dia, mes, ano);
	}
}