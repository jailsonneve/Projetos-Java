package Atv04;
import java.util.Scanner;

public class TestaAtv04 {
    public static String dadosTempo() {
        return "Tipo inexistente";
    }

    public static boolean verificaNegativo(int valor) {
        return valor < 0;
    }

    public static void main(String[] args) {
        Scanner batata = new Scanner(System.in);

        System.out.println("Digite se você quer data, horario ou tempo");
        String op = batata.nextLine().trim().toLowerCase();

        if (op.equals("data")) {
            System.out.println("\n---------------Datas----------------\n");

            System.out.println("Digite o dia: ");
            int dia = batata.nextInt();
            
            System.out.println("Digite o mês: ");
            int mes = batata.nextInt();

            System.out.println("Digite o ano: ");
            int ano = batata.nextInt();
            if (!verificaNegativo(dia) && !verificaNegativo(mes) && !verificaNegativo(ano)) {
                // Normalizar o mês e ano
                int anoAdicional = mes / 12;
                mes = mes % 12;
                ano += anoAdicional;

                // Ajustar para o intervalo válido de meses e dias
                if (mes < 1) mes = 1;
                if (mes > 12) mes = 12;

                int diasNoMes;
                switch (mes) {
                    case 2:
                        // Verifica se o ano é bissexto
                        diasNoMes = (ano % 4 == 0 && (ano % 100 != 0 || ano % 400 == 0)) ? 29 : 28;
                        break;
                    case 4: case 6: case 9: case 11:
                        diasNoMes = 30;
                        break;
                    default:
                        diasNoMes = 31;
                        break;
                }

                if (dia < 1) dia = 1;
                if (dia > diasNoMes) dia = diasNoMes;

                Data d1 = new Data();
                d1.data(dia, mes, ano);

                System.out.printf("Data: %02d/%02d/%04d", d1.getDia(), d1.getMes(), d1.getAno());
                
                System.out.println("\nQuantidade\n");
                System.out.println(d1.quantidade());
                
                System.out.println("\ntoString\n");
                System.out.println(d1.toString());
            } else {
                System.out.println("Digite um Valor positivo");
            }
        } else if (op.equals("horario")) {
            System.out.println("\n---------------Horarios----------------\n");

            System.out.println("Digite a hora: ");
            int hora = batata.nextInt();

            System.out.println("Digite o minuto: ");
            int minuto = batata.nextInt();

            System.out.println("Digite o segundo: ");
            int segundo = batata.nextInt();

            if (!verificaNegativo(hora) && !verificaNegativo(minuto) && !verificaNegativo(segundo)) {
                // Normalizar os valores de hora, minuto e segundo
                int adicionalHora = minuto / 60;
                minuto = minuto % 60;
                int adicionalMinuto = segundo / 60;
                segundo = segundo % 60;
                hora = (hora + adicionalHora) % 24;
                minuto = (minuto + adicionalMinuto) % 60;

                // Criar uma instância de Horario com os valores ajustados
                Horario h1 = new Horario();
                h1.setHora(hora);
                h1.setMinuto(minuto);
                h1.setSegundo(segundo);

                System.out.printf("\nHorario: %02d:%02d:%02d\n", h1.getHora(), h1.getMinuto(), h1.getSegundo());
                
                System.out.println("\nQuantidade\n");
                System.out.println(h1.quantidade());
                
                System.out.println("\ntoString\n");
                System.out.println(h1.toString());
            } else {
                System.out.println("Digite um Valor positivo");
            }

        } else if (op.equals("tempo")) {
            System.out.println("\n---------------Tempo----------------\n");
            Tempo t1 = new Tempo();

            System.out.println("\nQuantidade\n");
            System.out.println(t1.quantidade());

            System.out.println("\ntoString\n");
            System.out.println(t1.toString());
        } else {
            System.out.println(dadosTempo());
        }

        batata.close();
    }
}
