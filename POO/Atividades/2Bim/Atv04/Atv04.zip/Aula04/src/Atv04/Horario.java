package Atv04;

public class Horario extends Tempo {
	private Integer hora;
	private Integer minuto;
	private Integer segundo;
	
	public void Horario() {
	}
	public void Horario(Integer hora,Integer minuto,Integer segundo) {
		this.hora = hora;
		this.minuto = minuto;
		this.segundo = segundo;
	}
	public void setHora(Integer hora) {
		this.hora = hora;
	}
	public void setMinuto(Integer minuto) {
		this.minuto = minuto;
	}
	public void setSegundo(Integer segundo) {
		this.segundo = segundo;
	}
	
	public Integer getHora() {
		return this.hora;
	}
	public Integer getMinuto() {
		return this.minuto;
	}
	public Integer getSegundo() {
		return this.segundo;
	}
	
	public long quantidade() {
		if (hora != null && minuto != null && segundo != null) {
			return (hora * 3600 + minuto * 60 + segundo);
		} else {
			return 0;
		}
	}
	public String toString() {
		return (hora + ":" + minuto + ":" + segundo);
	}
}
