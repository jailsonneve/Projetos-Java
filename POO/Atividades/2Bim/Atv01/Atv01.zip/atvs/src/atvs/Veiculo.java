package atvs;

public class Veiculo {
	public int velocidade;
	public boolean status;
	
	public void ligar() {
		status = true;
	}
	public void desligar() {
		status = false;
	}
	public String mostarStatus() {
		String mostrar = "Status: " + status + "\nVelocidade: " + velocidade;
		velocidade = 0;
		return mostrar;
	}
	public void acelerar() {
		velocidade++;
	}
}
