package atvs;

public class TestaVeiculo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Veiculo veiculo1 = new Veiculo();
		
		veiculo1.status = true;
		veiculo1.velocidade = 100;
		
		veiculo1.acelerar();
		veiculo1.acelerar();
		
		veiculo1.desligar();
		
		System.out.println(veiculo1.mostarStatus()); 
	}

}
