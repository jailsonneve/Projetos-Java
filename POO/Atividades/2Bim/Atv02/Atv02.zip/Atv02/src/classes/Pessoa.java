package classes;

public class Pessoa {
	private String nome1 = "";
	private String endereco = "";
	public void setNome(String nome) {
		nome1 = nome;
	}
	public String getNome() {
		return nome1;
	}
	public void setEndereco(String inputEndereco) {
		endereco = inputEndereco;
	}
	public String getEndereco() {
		return endereco;
	}
}
