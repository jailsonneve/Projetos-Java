package classes;

public class TestaPessoa {
	public static void main(String[] args) {
		String nome1;
		String endereco1;
		Pessoa p1 = new Pessoa();
		
		p1.setNome("arthur");
		p1.setEndereco("bairro periollo");
		
		nome1 = p1.getNome();
		endereco1 = p1.getEndereco();
		
		System.out.println("Nome: " + nome1);
		System.out.println("Endereço: " + endereco1);
	}
}
