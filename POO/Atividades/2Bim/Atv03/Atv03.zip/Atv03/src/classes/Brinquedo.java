package classes;

public class Brinquedo {
	private String nome;
	private String faixaEtaria;
	private float preco;
	
	public Brinquedo() {}
	public Brinquedo(String nome) {
		this.nome = nome;
	}
	public Brinquedo(String nome, float preco) {
		this.nome = nome;
		this.preco = preco;
	}
	public void setFaixaEtaria(String faixaEtaria) {
		if (faixaEtaria == "0 a 2" || faixaEtaria == "3 a 5" || faixaEtaria == "6 a 10" || faixaEtaria == "acima de 10") {
			this.faixaEtaria = faixaEtaria;
		} else {
			System.out.println("Digite um valor válido!!!");
		}
	}
	public void mostrar() {
		String m = "Nome: " + nome + "\nFaixa Etaria: " + faixaEtaria + "\nPreço: " + preco;
		System.out.println(m);
	}
}