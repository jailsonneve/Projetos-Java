package estanteLivro;

public class Livro {
	
	private  final String titulo;
	private Estante estante;
	
	public Livro(String titulo) {
		this.titulo = titulo;
	}
	
	public String getEstante() {
		return estante;
	}
	
	public void setEstante(Estante estante) {
		this.estante = estante;
	}
	
	public String toString() {
		return "Livro{ "+ titulo + ", estantes " + 
			(estante == null ? "-" : estante.getNom()) + " }";
	}
}
