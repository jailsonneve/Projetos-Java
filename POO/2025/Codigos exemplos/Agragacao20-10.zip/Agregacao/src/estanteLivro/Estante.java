package estanteLivro;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Estante {
	
	private final String nome;
	private final List<Livro> livros = new ArrayList<Livro>();
	
	public Estante (String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void addLivro(Livro livro) {
		if (!livro.contains(livro)) {
			livro.add(livro);
			livro.setEstante(this);
		}
	}
	
	public void remLivro(Livro livro) {
		if (livro.remove(livro)) {
			livro.setEstante(null);
		}
	}
	
	public void desfazerVinculoSemApagarLivros() {
		for(Livro l: List.copyOf(livros)) {
			remover(l);
		}
	}
	
}
