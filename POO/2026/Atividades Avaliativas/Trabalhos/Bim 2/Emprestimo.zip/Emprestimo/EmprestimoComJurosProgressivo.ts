import { Emprestimo } from "./Emprestimo";

export class EmprestimoComJurosProgressivo extends Emprestimo {

    private acrescimoJuros: number;

    constructor(
        saldo: number,
        parcelas: number,
        jurosInicial: number,
        acrescimoJuros: number
    ) {
        super(saldo, parcelas, jurosInicial);

        this.acrescimoJuros = acrescimoJuros;
    }

    public getAcrescimoJuros(): number {
        return this.acrescimoJuros;
    }

    public override proximaParcela(): number {

        let retorno = this.p;

        this.corrente++;

        if (this.corrente <= this.n) {

            this.p = this.p + (
                this.p * (this.j / 100)
            );

            this.j += this.acrescimoJuros;

        } else {
            this.p = 0;
        }

        return retorno;
    }
}