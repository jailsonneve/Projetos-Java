import { Emprestimo } from "./Emprestimo";

export class EmprestimoEducacional extends Emprestimo {

    private periodoIsencao: number;

    constructor(
        saldo: number,
        parcelas: number,
        juros: number,
        periodoIsencao: number
    ) {
        super(saldo, parcelas, juros);

        this.periodoIsencao = periodoIsencao;
    }

    public getPeriodoIsencao(): number {
        return this.periodoIsencao;
    }

    public override proximaParcela(): number {

        let retorno = this.p;

        this.corrente++;

        if (this.corrente <= this.n) {

            if (this.corrente <= this.periodoIsencao + 1) {
                this.p = this.p;
            } else {
                this.p = this.p + (this.p * (this.j / 100));
            }

        } else {
            this.p = 0;
        }

        return retorno;
    }
}