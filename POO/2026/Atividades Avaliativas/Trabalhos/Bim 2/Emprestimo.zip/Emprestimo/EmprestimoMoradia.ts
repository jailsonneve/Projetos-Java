import { Emprestimo } from "./Emprestimo";

export class EmprestimoMoradia extends Emprestimo {

    private temSeguroMoradia: boolean;

    constructor(
        saldo: number,
        parcelas: number,
        juros: number,
        temSeguroMoradia: boolean
    ) {
        super(saldo, parcelas, juros);

        this.temSeguroMoradia = temSeguroMoradia;
    }

    public temSeguro(): boolean {
        return this.temSeguroMoradia;
    }

    public override proximaParcela(): number {

        let jurosAjustado = this.j;

        if (this.n > 120) {
            jurosAjustado = this.j * 0.85;
        }

        let retorno = this.p;

        if (this.temSeguroMoradia) {
            retorno += 10;
        }

        this.corrente++;

        if (this.corrente <= this.n) {
            this.p = this.p + (
                this.p * (jurosAjustado / 100)
            );
        } else {
            this.p = 0;
        }

        return retorno;
    }
}