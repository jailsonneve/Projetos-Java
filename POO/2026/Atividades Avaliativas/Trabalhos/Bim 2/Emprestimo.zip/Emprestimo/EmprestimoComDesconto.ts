import { Emprestimo } from "./Emprestimo";

export class EmprestimoComDesconto extends Emprestimo {

    private percentualDesconto: number;

    constructor(
        saldo: number,
        parcelas: number,
        juros: number,
        percentualDesconto: number
    ) {
        super(saldo, parcelas, juros);

        this.percentualDesconto = percentualDesconto;
    }

    public getPercentualDesconto(): number {
        return this.percentualDesconto;
    }

    public override proximaParcela(): number {

        let retorno = this.p;

        if (this.corrente == this.n) {
            retorno =
                retorno - (retorno * this.percentualDesconto / 100);
        }

        this.corrente++;

        if (this.corrente <= this.n) {
            this.p = this.p + (this.p * (this.j / 100));
        } else {
            this.p = 0;
        }

        return retorno;
    }
}