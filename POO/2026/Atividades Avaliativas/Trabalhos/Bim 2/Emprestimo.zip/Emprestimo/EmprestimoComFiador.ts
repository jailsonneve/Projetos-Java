import { Emprestimo } from "./Emprestimo";

export class EmprestimoComFiador extends Emprestimo {

    private temFiador: boolean;

    constructor(
        saldo: number,
        parcelas: number,
        juros: number,
        temFiador: boolean
    ) {
        super(saldo, parcelas, juros);
        this.temFiador = temFiador;
    }

    public verificarFiador(): boolean {
        return this.temFiador;
    }

    public override proximaParcela(): number {

        let jurosAjustado: number;

        if (this.temFiador) {
            jurosAjustado = this.j * 0.80;
        } else {
            jurosAjustado = this.j * 1.05;
        }

        let retorno = this.p;

        this.corrente++;

        if (this.corrente <= this.n) {
            this.p = this.p + (this.p * (jurosAjustado / 100));
        } else {
            this.p = 0;
        }

        return retorno;
    }
}