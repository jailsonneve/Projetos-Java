import { Emprestimo } from "./Emprestimo";

export class EmprestimoVeiculo extends Emprestimo {

    private tipo: string;

    constructor(
        saldo: number,
        parcelas: number,
        juros: number,
        tipo: string
    ) {
        super(saldo, parcelas, juros);

        this.tipo = tipo;
    }

    public getTipo(): string {
        return this.tipo;
    }

    public override proximaParcela(): number {

        let jurosAjustado = this.j;

        if (this.tipo === "usado") {
            jurosAjustado += 1;
        }

        let retorno = this.p;

        if (this.n > 60) {
            retorno += retorno * 0.02;
        }

        this.corrente++;

        if (this.corrente <= this.n) {
            this.p = this.p + (
                this.p * (jurosAjustado / 100)
            );
        } else {
            this.p = 0;
        }

        return retorno;
    }
}