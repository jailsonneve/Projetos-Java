package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBD {
    // Configurações do banco de dados
    private static final String URL = "jdbc:mysql://localhost:3306/ClinicaMultidisciplinar"; // Substitua "nome_do_banco" pelo nome do seu banco
    private static final String USER = "aluno"; // Usuário 
    private static final String PASSWORD = "aluno"; // Deixe vazio se não há senha configurada

    public static Connection connect() {
    	Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e){
			e.printStackTrace();
			System.out.println(e);
		}
		return conn;
    }
}
