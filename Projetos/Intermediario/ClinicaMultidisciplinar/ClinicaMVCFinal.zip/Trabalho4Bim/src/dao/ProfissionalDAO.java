package dao;

import Model.Profissional;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProfissionalDAO {

    // Método para cadastrar
    public void cadastrarProfissional(Profissional profissional) throws ExceptionDAO {
        String sql = "INSERT INTO Profissionais (nome, data_nascimento, rg, especializacao, especificacoes) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, profissional.getNome());
            stmt.setString(2, profissional.getDataNascimento());
            stmt.setString(3, profissional.getRg());
            stmt.setString(4, profissional.getEspecializacao());
            stmt.setString(5, profissional.getEspecificacoes());
            stmt.execute();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao cadastrar profissional: " + e.getMessage());
        }
    }

    // Método para listar
    public List<Profissional> listarProfissionais() throws ExceptionDAO {
        String sql = "SELECT * FROM Profissionais";
        List<Profissional> profissionais = new ArrayList<>();
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Profissional profissional = new Profissional(
                        rs.getString("nome"),
                        rs.getString("data_nascimento"),
                        rs.getString("rg"),
                        rs.getString("especializacao"),
                        rs.getString("especificacoes")
                );
                profissional.setId(rs.getInt("id")); // Setando o ID do profissional
                profissionais.add(profissional);
            }
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao listar profissionais: " + e.getMessage());
        }
        return profissionais;
    }

    // Método para alterar
    public void alterarProfissional(Profissional profissional) throws ExceptionDAO {
        String sql = "UPDATE Profissionais SET nome = ?, data_nascimento = ?, rg = ?, especializacao = ?, especificacoes = ? WHERE id = ?";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, profissional.getNome());
            stmt.setString(2, profissional.getDataNascimento());
            stmt.setString(3, profissional.getRg());
            stmt.setString(4, profissional.getEspecializacao());
            stmt.setString(5, profissional.getEspecificacoes());
            stmt.setInt(6, profissional.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao alterar profissional: " + e.getMessage());
        }
    }

    // Método para excluir
    public void excluirProfissional(int id) throws ExceptionDAO {
        String sql = "DELETE FROM Profissionais WHERE id = ?";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao excluir profissional: " + e.getMessage());
        }
    }
}
