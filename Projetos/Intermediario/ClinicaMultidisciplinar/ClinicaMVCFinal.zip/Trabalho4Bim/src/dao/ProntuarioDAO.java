package dao;

import Model.Prontuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProntuarioDAO {

	public void salvarProntuario(Prontuario prontuario) throws Exception {
        String sql = "INSERT INTO Prontuarios (id_paciente, sintomas, habitos, evolucao, medicamentos, observacoes) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = new ConexaoBD().connect();
            PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, prontuario.getIdPaciente());
            stmt.setString(2, prontuario.getSintomas());
            stmt.setString(3, prontuario.getHabitos());
            stmt.setString(4, prontuario.getEvolucao());
            stmt.setString(5, prontuario.getMedicamentos());
            stmt.setString(6, prontuario.getObservacoes());
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new Exception("Erro ao salvar prontuário: " + e.getMessage());
        }
    }

    public List<Prontuario> listarProntuarios() throws Exception {
        String sql = "SELECT * FROM Prontuarios";
        List<Prontuario> lista = new ArrayList<>();
        try (Connection conn = new ConexaoBD().connect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Prontuario prontuario = new Prontuario();
                prontuario.setId(rs.getInt("id"));
                prontuario.setIdPaciente(rs.getInt("id_paciente"));
                prontuario.setSintomas(rs.getString("sintomas"));
                prontuario.setHabitos(rs.getString("habitos"));
                prontuario.setEvolucao(rs.getString("evolucao"));
                prontuario.setMedicamentos(rs.getString("medicamentos"));
                prontuario.setObservacoes(rs.getString("observacoes"));
                lista.add(prontuario);
            }
        } catch (Exception e) {
            throw new Exception("Erro ao listar prontuários: " + e.getMessage());
        }
        return lista;
    }

    public void excluirProntuario(int id) throws Exception {
        String sql = "DELETE FROM Prontuarios WHERE id = ?";
        try (Connection conn = new ConexaoBD().connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new Exception("Erro ao excluir prontuário: " + e.getMessage());
        }
    }
}
