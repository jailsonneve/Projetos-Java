// ExceptionDAO.java
package dao;

public class ExceptionDAO extends Exception {
    private static final long serialVersionUID = 1L;

    public ExceptionDAO(String mensagem) {
        super(mensagem);
    }
}