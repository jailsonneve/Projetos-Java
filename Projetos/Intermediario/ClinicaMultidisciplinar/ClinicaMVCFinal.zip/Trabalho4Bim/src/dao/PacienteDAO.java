package dao;

import Model.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {

    public void cadastrarPaciente(Paciente paciente) throws ExceptionDAO {
        String sql = "INSERT INTO Pacientes (nome, sexo, data_nascimento, rg, naturalidade, telefone, endereco) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getSexo());
            stmt.setString(3, paciente.getDataNascimento());
            stmt.setString(4, paciente.getRg());
            stmt.setString(5, paciente.getNaturalidade());
            stmt.setString(6, paciente.getTelefone());
            stmt.setString(7, paciente.getEndereco());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao cadastrar paciente: " + e.getMessage());
        }
    }

    public Paciente consultarPacientePorId(int id) throws ExceptionDAO {
        String sql = "SELECT * FROM Pacientes WHERE id = ?";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Paciente(rs.getString("nome"),rs.getString("sexo"),rs.getString("data_nascimento"),rs.getString("rg"),rs.getString("naturalidade"),rs.getString("telefone"),rs.getString("endereco"));
            }
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao consultar paciente: " + e.getMessage());
        }
        return null;
    }

    public List<Paciente> listarPacientes() throws ExceptionDAO {
        String sql = "SELECT * FROM Pacientes";
        List<Paciente> pacientes = new ArrayList<>();

        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Paciente paciente = new Paciente(
                        rs.getString("nome"),
                        rs.getString("sexo"),
                        rs.getString("data_nascimento"),
                        rs.getString("rg"),
                        rs.getString("naturalidade"),
                        rs.getString("telefone"),
                        rs.getString("endereco")
                );
                paciente.setId(rs.getInt("id"));
                pacientes.add(paciente);
            }
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao listar pacientes: " + e.getMessage());
        }
        return pacientes;
    }

    public void alterarPaciente(Paciente paciente) throws ExceptionDAO {
        String sql = "UPDATE Pacientes SET nome = ?, sexo = ?, data_nascimento = ?, rg = ?, naturalidade = ?, telefone = ?, endereco = ? WHERE id = ?";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getSexo());
            stmt.setString(3, paciente.getDataNascimento());
            stmt.setString(4, paciente.getRg());
            stmt.setString(5, paciente.getNaturalidade());
            stmt.setString(6, paciente.getTelefone());
            stmt.setString(7, paciente.getEndereco());
            stmt.setInt(8, paciente.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao alterar paciente: " + e.getMessage());
        }
    }

    public void excluirPaciente(int id) throws ExceptionDAO {
        String sql = "DELETE FROM Pacientes WHERE id = ?";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao excluir paciente: " + e.getMessage());
        }
    }
}