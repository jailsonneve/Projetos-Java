package dao;

import Model.ListaEspera;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ListaEsperaDAO {

    // Método para adicionar um paciente à lista de espera
    public void adicionarNaLista(ListaEspera listaEspera) throws Exception {
        String sql = "INSERT INTO ListaEspera (id_paciente, id_profissional, data_solicitada, status) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = new ConexaoBD().connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, listaEspera.getIdPaciente()); // ID do paciente
            stmt.setInt(2, listaEspera.getIdProfissional()); // ID do profissional
            stmt.setString(3, listaEspera.getDataSolicitada()); // Data solicitada
            stmt.setString(4, listaEspera.getStatus()); // Status, que pode ser 'Aguardando', 'Remanejado', ou 'Atendido'
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new Exception("Erro ao adicionar na lista de espera: " + e.getMessage());
        }
    }

    // Método para listar todos os pacientes na lista de espera
    public List<ListaEspera> listarEspera() throws Exception {
        String sql = "SELECT * FROM ListaEspera";
        List<ListaEspera> lista = new ArrayList<>();
        
        try (Connection conn = new ConexaoBD().connect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                ListaEspera listaEspera = new ListaEspera();
                listaEspera.setId(rs.getInt("id"));
                listaEspera.setIdPaciente(rs.getInt("id_paciente"));
                listaEspera.setIdProfissional(rs.getInt("id_profissional"));
                listaEspera.setDataSolicitada(rs.getString("data_solicitada"));
                listaEspera.setStatus(rs.getString("status"));
                lista.add(listaEspera);
            }
        } catch (Exception e) {
            throw new Exception("Erro ao listar a lista de espera: " + e.getMessage());
        }
        return lista;
    }

    // Método para remover um paciente da lista de espera
    public void removerDaLista(int id) throws Exception {
        String sql = "DELETE FROM ListaEspera WHERE id = ?";
        
        try (Connection conn = new ConexaoBD().connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new Exception("Erro ao remover da lista de espera: " + e.getMessage());
        }
    }
}
