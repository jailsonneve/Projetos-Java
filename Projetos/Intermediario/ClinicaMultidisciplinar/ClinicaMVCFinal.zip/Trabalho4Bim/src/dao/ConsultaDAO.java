package dao;

import Model.Consulta;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAO {

    public void agendarConsulta(Consulta consulta) throws ExceptionDAO {
        String sql = "INSERT INTO Consultas (id_paciente, id_profissional, data_consulta, horario, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = new ConexaoBD().connect();
            PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, consulta.getIdPaciente());
            stmt.setInt(2, consulta.getIdProfissional());
            stmt.setString(3, consulta.getData());
            stmt.setString(4, consulta.getHorario());
            stmt.setString(5, consulta.getStatus());
            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ExceptionDAO("Erro ao agendar consulta: " + e);
        }
    }

    public Consulta consultarConsulta(int id) throws ExceptionDAO {
        String sql = "SELECT * FROM Consultas WHERE id = ?";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Consulta consulta = new Consulta();
                consulta.setId(rs.getInt("id"));
                consulta.setIdPaciente(rs.getInt("id_paciente"));
                consulta.setIdProfissional(rs.getInt("id_profissional"));
                consulta.setData(rs.getString("data_consulta"));
                consulta.setHorario(rs.getString("horario"));
                consulta.setStatus(rs.getString("status"));
                return consulta;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ExceptionDAO("Erro ao consultar consulta: " + e);
        }
        return null;
    }

    public List<Consulta> listarConsultas() throws ExceptionDAO {
        String sql = "SELECT * FROM Consultas";
        List<Consulta> consultas = new ArrayList<>();
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Consulta consulta = new Consulta();
                consulta.setId(rs.getInt("id"));
                consulta.setIdPaciente(rs.getInt("id_paciente"));
                consulta.setIdProfissional(rs.getInt("id_profissional"));
                consulta.setData(rs.getString("data_consulta"));
                consulta.setHorario(rs.getString("horario"));
                consulta.setStatus(rs.getString("status"));
                consultas.add(consulta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ExceptionDAO("Erro ao listar consultas: " + e);
        }
        return consultas;
    }

    public void alterarConsulta(Consulta consulta) throws ExceptionDAO {
        String sql = "UPDATE Consultas SET id_paciente = ?, id_profissional = ?, data_consulta = ?, horario = ?, status = ? WHERE id = ?";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, consulta.getIdPaciente());
            stmt.setInt(2, consulta.getIdProfissional());
            stmt.setString(3, consulta.getData());
            stmt.setString(4, consulta.getHorario());
            stmt.setString(5, consulta.getStatus());
            stmt.setInt(6, consulta.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ExceptionDAO("Erro ao alterar consulta: " + e);
        }
    }

    public void cancelarConsulta(int id) throws ExceptionDAO {
        String sql = "DELETE FROM Consultas WHERE id = ?";
        try (Connection connection = new ConexaoBD().connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ExceptionDAO("Erro ao cancelar consulta: " + e);
        }
    }
}
