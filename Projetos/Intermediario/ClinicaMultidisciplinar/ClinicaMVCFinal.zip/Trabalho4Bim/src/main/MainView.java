package main;

import javax.swing.*;

import View.ConsultaView;
import View.ListaEsperaView;
import View.PacienteView;
import View.ProfissionalView;
import View.ProntuarioView;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainView extends JFrame {
    private JButton consultaButton, listaEsperaButton, pacienteButton, profissionalButton, prontuarioButton;

    public MainView() {
        setTitle("Sistema de Gerenciamento");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centralizar a janela
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        consultaButton = criarBotao("Gerenciamento de Consulta");
        listaEsperaButton = criarBotao("Gerenciamento da Lista de Espera");
        pacienteButton = criarBotao("Gerenciamento de Paciente");
        profissionalButton = criarBotao("Gerenciamento de Profissional");
        prontuarioButton = criarBotao("Gerenciamento de Prontuário");

        // Ações dos botões
        consultaButton.addActionListener(e -> abrirConsultaView());
        listaEsperaButton.addActionListener(e -> abrirListaEsperaView());
        pacienteButton.addActionListener(e -> abrirPacienteView());
        profissionalButton.addActionListener(e -> abrirProfissionalView());
        prontuarioButton.addActionListener(e -> abrirProntuarioView());

        // Adicionando botões
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(consultaButton, gbc);

        gbc.gridy = 1;
        add(listaEsperaButton, gbc);

        gbc.gridy = 2;
        add(pacienteButton, gbc);

        gbc.gridy = 3;
        add(profissionalButton, gbc);

        gbc.gridy = 4;
        add(prontuarioButton, gbc);
    }

    private void abrirConsultaView() {
        new ConsultaView().setVisible(true);
    }

    private void abrirListaEsperaView() {
        new ListaEsperaView().setVisible(true);
    }

    private void abrirPacienteView() {
        new PacienteView().setVisible(true);
    }

    private void abrirProfissionalView() {
        new ProfissionalView().setVisible(true);
    }

    private void abrirProntuarioView() {
        new ProntuarioView().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainView().setVisible(true));
    }
    
    private JButton criarBotao(String texto) {
        JButton botao = new JButton(texto);
        botao.setFocusPainted(false);
        botao.setFont(new Font("Arial", Font.PLAIN, 14));
        botao.setBackground(new Color(70, 130, 180));
        botao.setForeground(Color.WHITE);
        return botao;
    }
}
