package Model;

import dao.*;

public class Prontuario {
    private int id;
    private int idPaciente;
    private String sintomas;
    private String habitos;
    private String evolucao;
    private String medicamentos;
    private String observacoes;

    public Prontuario(int idPaciente, String sintomas, String habitos, String evolucao, String medicamentos, String observacoes) {
    	this.idPaciente = idPaciente;
    	this.sintomas = sintomas;
    	this.habitos = habitos;
    	this.evolucao = evolucao;
    	this.medicamentos = medicamentos;
    	this.observacoes = observacoes;
    }
    
    public Prontuario() {}
    
    public int getId() { 
    	return id; 
    }
    
    public void setId(int id) { 
    	this.id = id; 
    }
    
    public int getIdPaciente() { 
    	return idPaciente; 
    }
    
    public void setIdPaciente(int idPaciente) { 
    	this.idPaciente = idPaciente; 
    }
    
    public String getSintomas() { 
    	return sintomas; 
    }
    
    public void setSintomas(String sintomas) { 
    	this.sintomas = sintomas; 
    }
    
    public String getHabitos() { 
    	return habitos; 
    }
    
    public void setHabitos(String habitos) { 
    	this.habitos = habitos; 
    }
    
    public String getEvolucao() { 
    	return evolucao; 
    }
    
    public void setEvolucao(String evolucao) { 
    	this.evolucao = evolucao; 
    }
    
    public String getMedicamentos() { 
    	return medicamentos; 
    }
    
    public void setMedicamentos(String medicamentos) { 
    	this.medicamentos = medicamentos; 
    }
    
    public String getObservacoes() { 
    	return observacoes; 
    }
    
    public void setObservacoes(String observacoes) { 
    	this.observacoes = observacoes; 
    }
    
    public void salvarProntuario(Prontuario prontuario) {
    	try {
			new ProntuarioDAO().salvarProntuario(prontuario);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
