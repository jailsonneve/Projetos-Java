package Model;

import java.util.List;

import dao.ExceptionDAO;
import dao.ProfissionalDAO;
import dao.ProntuarioDAO;

public class Profissional {
    private int id;
    private String nome;
    private String dataNascimento;
    private String rg;
    private String especializacao;
    private String especificacoes;

    public Profissional(String nome, String dataNascimento, String rg, String especializacao, String especificacoes) {
    	this.nome = nome;
    	this.dataNascimento = dataNascimento;
    	this.rg = rg;
    	this.especializacao = especializacao;
    	this.especificacoes = especificacoes;
    }
    
    public Profissional() {}

	public int getId() { 
    	return id; 
    }
    public void setId(int id) { 
    	this.id = id; 
    }
    public String getNome() { 
    	return nome; 
    }
    public void setNome(String nome) { 
    	this.nome = nome; 
    }
    public String getDataNascimento() { 
    	return dataNascimento; 
    }
    public void setDataNascimento(String dataNascimento) { 
    	this.dataNascimento = dataNascimento; 
    }
    public String getRg() { 
    	return rg; 
    }
    public void setRg(String rg) { 
    	this.rg = rg; 
    }
    public String getEspecializacao() { 
    	return especializacao; 
    }
    public void setEspecializacao(String especializacao) { 
    	this.especializacao = especializacao; 
    } 
    public String getEspecificacoes() { 
    	return especificacoes; 
    }
    public void setEspecificacoes(String especificacoes) { 
    	this.especificacoes = especificacoes; 
    }
    public void salvarProfissional(Profissional profissional) {
    	try {
			new ProfissionalDAO().cadastrarProfissional(profissional);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    public List<Profissional> listarProfissionais() {
    	try {
			return new ProfissionalDAO().listarProfissionais();
		} catch (ExceptionDAO e) {
			e.printStackTrace();
		}
		return null;
    }
    public void alterarProfissional(Profissional profissional) {
    	try {
			new ProfissionalDAO().alterarProfissional(profissional);
		} catch (ExceptionDAO e) {
			e.printStackTrace();
		}
    }
    public void excluirProfissional(int id) {
    	try {
			new ProfissionalDAO().excluirProfissional(id);
		} catch (ExceptionDAO e) {
			e.printStackTrace();
		}
    }
}
