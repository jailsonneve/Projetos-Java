package Model;

import java.util.List;

import dao.*;

public class ListaEspera {
    private int id;
    private int idPaciente;
    private int idProfissional;
    private String dataSolicitada;
    private String status;

    public ListaEspera(int idPaciente, int idProfissional, String dataSolicitada, String status) {
    	this.idPaciente = idPaciente;
    	this.idProfissional = idProfissional;
    	this.dataSolicitada = dataSolicitada;
    	this.status = status;
    }
    
    public ListaEspera() {}

	public int getId() { 
    	return id; 
    }
    
    public void setId(int id) { 
    	this.id = id; 
    }
    
    public int getIdPaciente() { 
    	return idPaciente; 
    }
    
    public void setIdPaciente(int idPaciente) { 
    	this.idPaciente = idPaciente; 
    }
    
    public int getIdProfissional() { 
    	return idProfissional; 
    }
    
    public void setIdProfissional(int idProfissional) { 
    	this.idProfissional = idProfissional; 
    }
    
    public String getDataSolicitada() { 
    	return dataSolicitada; 
    }
    
    public void setDataSolicitada(String dataSolicitada) { 
    	this.dataSolicitada = dataSolicitada; 
    }
    
    public String getStatus() { 
    	return status; 
    }
    
    public void setStatus(String status) { 
    	this.status = status; 
    }
    public void adicionarNaLista(ListaEspera listaEspera) {
    	try {
            new ListaEsperaDAO().adicionarNaLista(listaEspera);
            System.out.println("Paciente adicionado à lista de espera.");
        } catch (Exception e) {
            System.err.println("Erro ao adicionar na lista de espera: " + e.getMessage());
        }
    }
    public List<ListaEspera> listarEspera() {
        try {
            return new ListaEsperaDAO().listarEspera();
        } catch (Exception e) {
            System.err.println("Erro ao listar a fila de espera: " + e.getMessage());
            return null;
        }
    }
    public void removerDaLista(int id) {
        try {
            new ListaEsperaDAO().removerDaLista(id);
            System.out.println("Paciente removido da lista de espera.");
        } catch (Exception e) {
            System.err.println("Erro ao remover da lista de espera: " + e.getMessage());
        }
    }
}
