package Model;

import java.util.List;

import javax.swing.JOptionPane;

import dao.ExceptionDAO;
import dao.PacienteDAO;

public class Paciente {
	
	private int id;
    private String nome;
    private String sexo;
    private String dataNascimento;
    private String rg;
    private String naturalidade;
    private String telefone;
    private String endereco;
    
    public Paciente(String nome, String sexo, String dataNascimento, String rg, String naturalidade, String telefone, String endereco) {
    	this.nome = nome;
    	this.sexo = sexo;
    	this.dataNascimento = dataNascimento;
    	this.rg = rg;
    	this.naturalidade = naturalidade;
    	this.telefone = telefone;
    	this.endereco = endereco;
    }
    
	public Paciente() {}

	public int getId() {
		return this.id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNome() { 
		return nome; 
	}
	
    public void setNome(String nome) { 
    	this.nome = nome; 
    }
    
    public String getSexo() { 
    	return sexo; 
    }
    
    public void setSexo(String sexo) { 
    	this.sexo = sexo; 
    }
    
    public String getDataNascimento() { 
    	return dataNascimento; 
    }
    
    public void setDataNascimento(String dataNascimento) {
    	this.dataNascimento = dataNascimento; 
    }
    
    public String getRg() { 
    	return rg; 
    }
    
    public void setRg(String rg) { 
    	this.rg = rg; 
    }
    
    public String getNaturalidade() { 
    	return naturalidade; 
    }
    
    public void setNaturalidade(String naturalidade) { 
    	this.naturalidade = naturalidade; 
    }
    
    public String getTelefone() { 
    	return telefone; 
    }
    
    public void setTelefone(String telefone) { 
    	this.telefone = telefone; 
    }
    
    public String getEndereco() { 
    	return endereco; 
    }
    
    public void setEndereco(String endereco) { 
    	this.endereco = endereco; 
    }
    
    public void salvarPaciente(Paciente paciente) {
        try {
            new PacienteDAO().cadastrarPaciente(paciente);
        } catch (Exception e) {
            System.err.println("Erro ao salvar paciente: " + e.getMessage());
        }
    }
    
    public void excluirPaciente(int id) {
    	try {
			new PacienteDAO().excluirPaciente(id);
		} catch (ExceptionDAO e) {
			e.printStackTrace();
		}
    }
    
    public void alterarPaciente(Paciente paciente) {
		try {
			new PacienteDAO().alterarPaciente(paciente);
		} catch (Exception e) {
			System.out.println("DEU RUIM!!!" + e);
		}
	}
    
    public String[] getValores() {
    	String[] valores = {getNome(), getSexo(), getDataNascimento(), getRg(), getNaturalidade(), getTelefone(), getEndereco()};
    	return valores;
    }
    public Paciente consultarPacientePorId(int id) {
		try {
			return new PacienteDAO().consultarPacientePorId(id);
		} catch (ExceptionDAO e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Paciente> listarPacientes() {
		try {
            return new PacienteDAO().listarPacientes();
        } catch (Exception e) {
            System.err.println("Erro ao listar pacientes: " + e.getMessage());
            return null;
        }
	}
}