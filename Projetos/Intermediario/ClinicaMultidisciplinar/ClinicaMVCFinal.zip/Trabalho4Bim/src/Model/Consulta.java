package Model;

import java.util.List;

import dao.ConsultaDAO;

public class Consulta {
    private int id;
    private int idPaciente;
    private int idProfissional;
    private String data;
    private String horario;
    private String status;
    
    public Consulta() {}

    public Consulta(int idPaciente, int idProfissional, String data, String horario, String status) {
    	this.idPaciente = idPaciente;
    	this.idProfissional = idProfissional;
    	this.data = data;
    	this.horario = horario;
    	this.status = status;
    }

	public int getId() { 
    	return id; 
    }
    
    public void setId(int id) { 
    	this.id = id; 
    }
    
    public int getIdPaciente() { 
    	return idPaciente; 
    }
    
    public void setIdPaciente(int idPaciente) { 
    	this.idPaciente = idPaciente; 
    }
    
    public int getIdProfissional() { 
    	return idProfissional; 
    }
    
    public void setIdProfissional(int idProfissional) { 
    	this.idProfissional = idProfissional; 
    }
    
    public String getData() { 
    	return data; 
    }
    
    public void setData(String data) { 
    	this.data = data; 
    }
    
    public String getHorario() { 
    	return horario; 
    }
    
    public void setHorario(String horario) { 
    	this.horario = horario; 
    }
    
    public String getStatus() { 
    	return status; 
    }
    
    public void setStatus(String status) { 
    	this.status = status; 
    }
    
    public void salvarConsulta(Consulta consulta) {
        try {
            new ConsultaDAO().agendarConsulta(consulta);
            System.out.println("Consulta salva com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao salvar consulta: " + e.getMessage());
        }
    }
    
    public List<Consulta> listarConsultas() {
        try {
            return new ConsultaDAO().listarConsultas();
        } catch (Exception e) {
            System.err.println("Erro ao listar consultas: " + e.getMessage());
            return null;
        }
    }
    
    public void excluirConsulta(int id) {
        try {
            new ConsultaDAO().cancelarConsulta(id);
            System.out.println("Consulta excluída com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao excluir consulta: " + e.getMessage());
        }
    }
    
    public Consulta consultarConsulta(int id) {
        try {
            return new ConsultaDAO().consultarConsulta(id);
        } catch (Exception e) {
            System.err.println("Erro ao consultar consulta: " + e.getMessage());
            return null;
        }
    }
    
    public void alterarConsulta(Consulta consulta) {
        try {
            new ConsultaDAO().alterarConsulta(consulta);
        } catch (Exception e) {
            System.err.println("Erro ao alterar consulta: " + e.getMessage());
        }
    }
}