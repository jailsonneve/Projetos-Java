package View;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import Controller.PacienteController;
import Model.Paciente;

public class PacienteView extends JFrame {

    public PacienteView() {
        setTitle("Gerenciamento de Pacientes");
        setSize(600, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.add("Cadastrar", criarTelaCadastrar());
        tabbedPane.add("Consultar", criarTelaConsultar());
        tabbedPane.add("Alterar", criarTelaAlterar());
        tabbedPane.add("Excluir", criarTelaExcluir());
        tabbedPane.add("Listar Todos", criarTelaListarTodos()); // Nova aba

        add(tabbedPane);

        setVisible(true);
    }

    private JPanel criarTelaCadastrar() {
        JPanel panel = criarFormulario(new String[]{"Nome", "Sexo", "Data de Nascimento", "CPF", "Naturalidade", "Telefone", "Endereço"});
        JButton confirmar = criarBotao("Confirmar");
        JButton cancelar = criarBotao("Cancelar");

        confirmar.addActionListener(e -> {
            JTextField[] campos = pegarCampos(panel);
            try {
                Paciente paciente = new Paciente(
                        campos[0].getText(), campos[1].getText(), campos[2].getText(),
                        campos[3].getText(), campos[4].getText(), campos[5].getText(), campos[6].getText()
                );
                new PacienteController().salvarPaciente(paciente);
                limparCampos(panel);
                JOptionPane.showMessageDialog(this, "Paciente cadastrado com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar paciente: " + ex.getMessage());
            }
        });

        cancelar.addActionListener(e -> dispose());
        panel.add(confirmar);
        panel.add(cancelar);
        return panel;
    }

    private JPanel criarTelaConsultar() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Digite o ID do paciente:", JLabel.CENTER);
        JTextField idField = new JTextField();

        JButton confirmar = criarBotao("Consultar");
        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                new PacienteController().consultarPacientePorId(id, this);
                limparCampos(panel);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
            }
        });

        panel.add(label);
        panel.add(idField);
        panel.add(confirmar);

        return panel;
    }

    private JPanel criarTelaAlterar() {
        JPanel panel = criarFormulario(new String[]{"ID", "Nome", "Sexo", "Data de Nascimento", "CPF", "Naturalidade", "Telefone", "Endereço"});
        JButton confirmar = criarBotao("Confirmar");
        JButton cancelar = criarBotao("Limpar");

        confirmar.addActionListener(e -> {
            JTextField[] campos = pegarCampos(panel);
            try {
                int id = Integer.parseInt(campos[0].getText());
                Paciente paciente = new Paciente(
                        campos[1].getText(), campos[2].getText(), campos[3].getText(),
                        campos[4].getText(), campos[5].getText(), campos[6].getText(), campos[7].getText()
                );
                paciente.setId(id);
                new PacienteController().alterarPaciente(paciente, this);
                limparCampos(panel);
                JOptionPane.showMessageDialog(this, "Paciente alterado com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao alterar paciente: " + ex.getMessage());
            }
        });

        cancelar.addActionListener(e -> dispose());
        panel.add(confirmar);
        panel.add(cancelar);
        return panel;
    }

    private JPanel criarTelaExcluir() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Digite o ID do paciente:", JLabel.CENTER);
        JTextField idField = new JTextField();

        JButton confirmar = criarBotao("Excluir");
        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                new PacienteController().excluirPaciente(id);
                JOptionPane.showMessageDialog(this, "Paciente excluído com sucesso!");
                limparCampos(panel);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao excluir paciente: " + ex.getMessage());
            }
        });

        panel.add(label);
        panel.add(idField);
        panel.add(confirmar);

        return panel;
    }

    private JButton criarBotao(String texto) {
        JButton botao = new JButton(texto);
        botao.setFocusPainted(false);
        botao.setFont(new Font("Arial", Font.PLAIN, 14));
        botao.setBackground(new Color(70, 130, 180));
        botao.setForeground(Color.WHITE);
        return botao;
    }

    private JPanel criarFormulario(String[] labels) {
        JPanel panel = new JPanel(new GridLayout(labels.length + 1, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        for (String label : labels) {
            panel.add(new JLabel(label + ":"));
            panel.add(new JTextField());
        }
        return panel;
    }

    private JPanel criarTelaListarTodos() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] colunas = {"ID", "Nome", "Sexo", "Data de Nascimento", "RG", "Naturalidade", "Telefone", "Endereço"};
        DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0);

        JTable tabela = new JTable(modeloTabela);
        JScrollPane scrollPane = new JScrollPane(tabela);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton botaoAtualizar = criarBotao("Atualizar Pacientes");
        botaoAtualizar.addActionListener(e -> atualizarTabela(modeloTabela));
        panel.add(botaoAtualizar, BorderLayout.SOUTH);

        // Carrega os dados inicialmente
        atualizarTabela(modeloTabela);

        return panel;
    }

    private void atualizarTabela(DefaultTableModel modeloTabela) {
        modeloTabela.setRowCount(0); // Limpa os dados antigos

        try {
            List<Paciente> pacientes = new PacienteController().listarPacientes();
            for (Paciente p : pacientes) {
                modeloTabela.addRow(new Object[]{
                        p.getId(), p.getNome(), p.getSexo(), p.getDataNascimento(),
                        p.getRg(), p.getNaturalidade(), p.getTelefone(), p.getEndereco()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao atualizar dados: " + e.getMessage());
        }
    }


    private JTextField[] pegarCampos(JPanel panel) {
    // Crie uma lista temporária para armazenar os JTextField encontrados
    	java.util.List<JTextField> listaCampos = new java.util.ArrayList<>();

    // Itere sobre todos os componentes do painel
    	for (Component comp : panel.getComponents()) {
        	if (comp instanceof JTextField) { // Verifique se o componente é um JTextField
            listaCampos.add((JTextField) comp);
        	}
    	}

    // Verifique se há pelo menos um campo JTextField, evitando problemas posteriores
    	if (listaCampos.isEmpty()) {
        	throw new IllegalStateException("Nenhum campo JTextField foi encontrado no painel.");
    	}

    	// Converta a lista para um array e retorne
    	return listaCampos.toArray(new JTextField[0]);
	}

    private void limparCampos(JPanel panel) {
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JTextField) {
                ((JTextField) comp).setText("");
            }
        }
    }

}
