package View;

import Controller.ProfissionalController;
import Model.Profissional;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ProfissionalView extends JFrame {
    private JTextField nomeField, dataNascimentoField, rgField, especializacaoField, especificacoesField;
    private JButton salvarButton, alterarButton, excluirButton;
    private JTable tabelaProfissionais;
    private DefaultTableModel tabelaModelo;
    private ProfissionalController controller;

    public ProfissionalView() {
        controller = new ProfissionalController();

        setTitle("Gerenciamento de Profissionais");
        setSize(600, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();

        // Aba de Cadastro
        JPanel cadastroPanel = criarPainelCadastro();
        tabbedPane.addTab("Cadastro", cadastroPanel);

        // Aba de Listagem
        JPanel listagemPanel = criarPainelListagem();
        tabbedPane.addTab("Listagem", listagemPanel);

        add(tabbedPane, BorderLayout.CENTER);

        atualizarTabela(); // Preenche a tabela ao iniciar
    }

    private JPanel criarPainelCadastro() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        nomeField = new JTextField(20);
        dataNascimentoField = new JTextField(20);
        rgField = new JTextField(20);
        especializacaoField = new JTextField(20);
        especificacoesField = new JTextField(20);
        salvarButton = criarBotao("Salvar");

        salvarButton.addActionListener(e -> {
        	Profissional profissional = new Profissional(nomeField.getText(), dataNascimentoField.getText(), rgField.getText(), especializacaoField.getText(), especificacoesField.getText());
            controller.salvarProfissional(profissional);
            atualizarTabela();
            limparCampos();
        });

        adicionarCampo(panel, gbc, "Nome:", nomeField, 0);
        adicionarCampo(panel, gbc, "Data de Nascimento:", dataNascimentoField, 1);
        adicionarCampo(panel, gbc, "CPF:", rgField, 2);
        adicionarCampo(panel, gbc, "Especialização:", especializacaoField, 3);
        adicionarCampo(panel, gbc, "Especificações:", especificacoesField, 4);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        panel.add(salvarButton, gbc);

        return panel;
    }

    private JPanel criarPainelListagem() {
        JPanel panel = new JPanel(new BorderLayout());
        tabelaModelo = new DefaultTableModel(new String[]{"ID", "Nome", "Especialização", "CPF" , "Especialização", "Especificações"}, 0);
        tabelaProfissionais = new JTable(tabelaModelo);

        JScrollPane scrollPane = new JScrollPane(tabelaProfissionais);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel botoesPanel = new JPanel(new FlowLayout());
        alterarButton = criarBotao("Alterar");
        excluirButton = criarBotao("Excluir");

        alterarButton.addActionListener(e -> alterarProfissional());
        excluirButton.addActionListener(e -> excluirProfissional());

        botoesPanel.add(alterarButton);
        botoesPanel.add(excluirButton);

        panel.add(botoesPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void adicionarCampo(JPanel panel, GridBagConstraints gbc, String label, JTextField field, int y) {
        gbc.gridx = 0;
        gbc.gridy = y;
        panel.add(new JLabel(label), gbc);

        gbc.gridx = 1;
        panel.add(field, gbc);
    }

    private void atualizarTabela() {
        List<Profissional> profissionais = controller.listarProfissionais();
        tabelaModelo.setRowCount(0); // Limpa a tabela antes de preencher
        if (profissionais != null) {
            for (Profissional p : profissionais) {
                tabelaModelo.addRow(new Object[]{p.getId(), p.getNome(), p.getDataNascimento(), p.getRg(), p.getEspecializacao(), p.getEspecificacoes()});
            }
        }
    }

    private void alterarProfissional() {
        int selectedRow = tabelaProfissionais.getSelectedRow();
        if (selectedRow >= 0) {
            int id = (int) tabelaModelo.getValueAt(selectedRow, 0);
            String nome = JOptionPane.showInputDialog(this, "Nome:", tabelaModelo.getValueAt(selectedRow, 1));
            String dataNascimento = JOptionPane.showInputDialog(this, "Data de Nascimento:", tabelaModelo.getValueAt(selectedRow, 2));
            String rg = JOptionPane.showInputDialog(this, "RG:", tabelaModelo.getValueAt(selectedRow, 3));
            String especializacao = JOptionPane.showInputDialog(this, "Especialização:", tabelaModelo.getValueAt(selectedRow, 4));
            String especificasao = JOptionPane.showInputDialog(this, "Especificação:", tabelaModelo.getValueAt(selectedRow, 5));
            

            if (nome != null && especializacao != null && rg != null) {
            	Profissional profissional = new Profissional(nome, dataNascimento, rg, especializacao, especificasao);
            	profissional.setId(id);
                controller.alterarProfissional(profissional);
                atualizarTabela();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um profissional para alterar.");
        }
    }

    private void excluirProfissional() {
        int selectedRow = tabelaProfissionais.getSelectedRow();
        if (selectedRow >= 0) {
            int id = (int) tabelaModelo.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Deseja realmente excluir o profissional?","Excluir profissional",JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                controller.excluirProfissional(id);
                atualizarTabela();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um profissional para excluir.");
        }
    }
    
    private JButton criarBotao(String texto) {
        JButton botao = new JButton(texto);
        botao.setFocusPainted(false);
        botao.setFont(new Font("Arial", Font.PLAIN, 14));
        botao.setBackground(new Color(70, 130, 180));
        botao.setForeground(Color.WHITE);
        return botao;
    }

    private void limparCampos() {
        nomeField.setText("");
        dataNascimentoField.setText("");
        rgField.setText("");
        especializacaoField.setText("");
        especificacoesField.setText("");
    }
}