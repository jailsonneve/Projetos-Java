package View;

import javax.swing.*;
import java.awt.*;
import Controller.ProntuarioController;
import Model.Prontuario;
import java.util.List;

public class ProntuarioView extends JFrame {

    public ProntuarioView() {
        setTitle("Gerenciamento de Prontuários");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.add("Cadastrar", criarTelaCadastrar());
        tabbedPane.add("Consultar", criarTelaConsultar());
        tabbedPane.add("Excluir", criarTelaExcluir());
        tabbedPane.add("Listar Prontuários", criarTelaListar());

        add(tabbedPane);
        setVisible(true);
    }

    private JPanel criarTelaCadastrar() {
        JPanel panel = criarFormulario(new String[]{"ID Paciente", "Sintomas", "Hábitos", "Evolução", "Medicamentos", "Observação"});
        JButton confirmar = criarBotao("Confirmar");
        JButton cancelar = criarBotao("Cancelar");

        confirmar.addActionListener(e -> {
            JTextField[] campos = pegarCampos(panel);
            try {
                Prontuario prontuario = new Prontuario(
                        Integer.parseInt(campos[0].getText()),
                        campos[1].getText(),
                        campos[2].getText(),
                        campos[3].getText(),
                        campos[4].getText(),
                        campos[5].getText()
                );
                new ProntuarioController().salvarProntuario(prontuario);
                limparCampos(panel);
                JOptionPane.showMessageDialog(this, "Prontuário cadastrado com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar prontuário: " + ex.getMessage());
            }
        });

        cancelar.addActionListener(e -> dispose());
        panel.add(confirmar);
        panel.add(cancelar);
        return panel;
    }

    private JPanel criarTelaConsultar() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Digite o ID do prontuário:", JLabel.CENTER);
        JTextField idField = new JTextField();

        JButton confirmar = criarBotao("Consultar");
        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                List<Prontuario> prontuarios = new ProntuarioController().listarProntuarios();
                Prontuario encontrado = prontuarios.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
                if (encontrado != null) {
                    JOptionPane.showMessageDialog(this, formatarProntuario(encontrado));
                } else {
                    JOptionPane.showMessageDialog(this, "Prontuário não encontrado.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
            }
        });

        panel.add(label);
        panel.add(idField);
        panel.add(confirmar);

        return panel;
    }

    private JPanel criarTelaExcluir() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Digite o ID do prontuário:", JLabel.CENTER);
        JTextField idField = new JTextField();

        JButton confirmar = criarBotao("Excluir");
        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                new ProntuarioController().excluirProntuario(id);
                JOptionPane.showMessageDialog(this, "Prontuário excluído com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao excluir prontuário: " + ex.getMessage());
            }
        });

        panel.add(label);
        panel.add(idField);
        panel.add(confirmar);

        return panel;
    }

    private JPanel criarTelaListar() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        JButton atualizar = criarBotao("Atualizar Lista");
        atualizar.addActionListener(e -> {
            try {
                List<Prontuario> prontuarios = new ProntuarioController().listarProntuarios();
                StringBuilder sb = new StringBuilder();
                for (Prontuario p : prontuarios) {
                    sb.append(formatarProntuario(p)).append("\n\n");
                }
                textArea.setText(sb.toString());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao listar prontuários: " + ex.getMessage());
            }
        });

        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        panel.add(atualizar, BorderLayout.SOUTH);

        return panel;
    }

    private JButton criarBotao(String texto) {
        JButton botao = new JButton(texto);
        botao.setFocusPainted(false);
        botao.setFont(new Font("Arial", Font.PLAIN, 14));
        botao.setBackground(new Color(70, 130, 180));
        botao.setForeground(Color.WHITE);
        return botao;
    }

    private JPanel criarFormulario(String[] labels) {
        JPanel panel = new JPanel(new GridLayout(labels.length + 1, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        for (String label : labels) {
            panel.add(new JLabel(label + ":"));
            panel.add(new JTextField());
        }
        return panel;
    }

    private JTextField[] pegarCampos(JPanel panel) {
        java.util.List<JTextField> listaCampos = new java.util.ArrayList<>();
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JTextField) {
                listaCampos.add((JTextField) comp);
            }
        }
        if (listaCampos.isEmpty()) {
            throw new IllegalStateException("Nenhum campo JTextField foi encontrado no painel.");
        }
        return listaCampos.toArray(new JTextField[0]);
    }

    private void limparCampos(JPanel panel) {
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JTextField) {
                ((JTextField) comp).setText("");
            }
        }
    }

    private String formatarProntuario(Prontuario prontuario) {
        return String.format(
                "ID: %d\nID Paciente: %d\nSintomas: %s\nHábitos: %s\nEvolução: %s\nMedicamentos: %s\nObservação: %s",
                prontuario.getId(), prontuario.getIdPaciente(), prontuario.getSintomas(),
                prontuario.getHabitos(), prontuario.getEvolucao(), prontuario.getMedicamentos(), prontuario.getObservacoes()
        );
    }
}