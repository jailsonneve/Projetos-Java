package View;

import javax.swing.*;
import java.awt.*;
import Controller.ListaEsperaController;
import Model.ListaEspera;
import java.util.List;

public class ListaEsperaView extends JFrame {

    public ListaEsperaView() {
        setTitle("Gerenciamento da Lista de Espera");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.add("Cadastrar", criarTelaCadastrar());
        tabbedPane.add("Consultar", criarTelaConsultar());
        tabbedPane.add("Excluir", criarTelaExcluir());
        tabbedPane.add("Listar Espera", criarTelaListar());

        add(tabbedPane);
        setVisible(true);
    }

    private JPanel criarTelaCadastrar() {
        // Criando o painel principal
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Espaçamento entre os componentes
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Adicionando os campos com suas labels
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("ID Paciente:"), gbc);

        JTextField idPacienteField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(idPacienteField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("ID Profissional:"), gbc);

        JTextField idProfissionalField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(idProfissionalField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Data Solicitada:"), gbc);

        JTextField dataSolicitadaField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(dataSolicitadaField, gbc);

        // Adicionando o JComboBox para Status
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Status:"), gbc);

        String[] statusOptions = {"Aguardando", "Remanejado", "Atendido"};
        JComboBox<String> statusComboBox = new JComboBox<>(statusOptions);
        statusComboBox.setFont(new Font("Arial", Font.PLAIN, 14)); // Estilizando a fonte
        gbc.gridx = 1;
        panel.add(statusComboBox, gbc);

        // Botões de Confirmar e Cancelar
        JButton confirmar = criarBotao("Confirmar");
        JButton cancelar = criarBotao("Cancelar");

        confirmar.addActionListener(e -> {
            try {
                // Pegando os valores dos campos
                ListaEspera listaEspera = new ListaEspera(
                        Integer.parseInt(idPacienteField.getText()),
                        Integer.parseInt(idProfissionalField.getText()),
                        dataSolicitadaField.getText(),
                        statusComboBox.getSelectedItem().toString() // Status selecionado
                );
                new ListaEsperaController().adicionarNaLista(listaEspera);
                limparCampos(panel); // Limpando os campos após salvar
                JOptionPane.showMessageDialog(this, "Paciente adicionado à lista de espera!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao adicionar paciente: " + ex.getMessage());
            }
        });

        cancelar.addActionListener(e -> dispose());

        // Adicionando os botões ao painel
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        JPanel botaoPanel = new JPanel();
        botaoPanel.add(confirmar);
        botaoPanel.add(cancelar);
        panel.add(botaoPanel, gbc);

        return panel;
    }
    
    private JPanel criarTelaConsultar() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Digite o ID da lista de espera:", JLabel.CENTER);
        JTextField idField = new JTextField();

        JButton confirmar = criarBotao("Consultar");
        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                List<ListaEspera> listaEspera = new ListaEsperaController().listarEspera();
                ListaEspera encontrado = listaEspera.stream().filter(l -> l.getId() == id).findFirst().orElse(null);
                limparCampos(panel); // Limpando os campos após salvar
                if (encontrado != null) {
                    JOptionPane.showMessageDialog(this, formatarListaEspera(encontrado));
                } else {
                    JOptionPane.showMessageDialog(this, "Paciente não encontrado na lista de espera.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
            }
        });

        panel.add(label);
        panel.add(idField);
        panel.add(confirmar);
        
        return panel;
    }

    private JPanel criarTelaExcluir() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Digite o ID da lista de espera:", JLabel.CENTER);
        JTextField idField = new JTextField();

        JButton confirmar = criarBotao("Excluir");
        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                new ListaEsperaController().removerDaLista(id);
                limparCampos(panel); // Limpando os campos após salvar
                JOptionPane.showMessageDialog(this, "Paciente removido da lista de espera com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao excluir paciente: " + ex.getMessage());
            }
        });

        panel.add(label);
        panel.add(idField);
        panel.add(confirmar);

        return panel;
    }

    private JPanel criarTelaListar() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        JButton atualizar = criarBotao("Atualizar Lista");
        atualizar.addActionListener(e -> {
            try {
                List<ListaEspera> listaEspera = new ListaEsperaController().listarEspera();
                StringBuilder sb = new StringBuilder();
                for (ListaEspera l : listaEspera) {
                    sb.append(formatarListaEspera(l)).append("\n\n");
                }
                textArea.setText(sb.toString());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao listar pacientes: " + ex.getMessage());
            }
        });

        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        panel.add(atualizar, BorderLayout.SOUTH);

        return panel;
    }

    private JButton criarBotao(String texto) {
        JButton botao = new JButton(texto);
        botao.setFocusPainted(false);
        botao.setFont(new Font("Arial", Font.PLAIN, 14));
        botao.setBackground(new Color(70, 130, 180));
        botao.setForeground(Color.WHITE);
        return botao;
    }

    private JPanel criarFormulario(String[] labels) {
        JPanel panel = new JPanel(new GridLayout(labels.length + 1, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        for (String label : labels) {
            panel.add(new JLabel(label + ":"));
            panel.add(new JTextField());
        }
        return panel;
    }

    private JTextField[] pegarCampos(JPanel panel) {
        java.util.List<JTextField> listaCampos = new java.util.ArrayList<>();
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JTextField) {
                listaCampos.add((JTextField) comp);
            }
        }
        if (listaCampos.isEmpty()) {
            throw new IllegalStateException("Nenhum campo JTextField foi encontrado no painel.");
        }
        return listaCampos.toArray(new JTextField[0]);
    }

    private void limparCampos(JPanel panel) {
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JTextField) {
                ((JTextField) comp).setText("");
            }
        }
    }

    private String formatarListaEspera(ListaEspera listaEspera) {
        return String.format(
                "ID: %d\nID Paciente: %d\nID Profissional: %d\nData Solicitada: %s\nStatus: %s",
                listaEspera.getId(), listaEspera.getIdPaciente(), listaEspera.getIdProfissional(),
                listaEspera.getDataSolicitada(), listaEspera.getStatus()
        );
    }
}
