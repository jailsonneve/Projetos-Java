package View;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import Controller.ConsultaController;
import Model.Consulta;
import java.util.List;

public class ConsultaView extends JFrame {

    public ConsultaView() {
        setTitle("Gerenciamento de Consultas");
        setSize(900, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.add("Cadastrar", criarTelaCadastrar());
        tabbedPane.add("Consultar", criarTelaConsultar());
        tabbedPane.add("Excluir", criarTelaExcluir());
        tabbedPane.add("Alterar", criarTelaAlterar());
        tabbedPane.add("Listar Consultas", criarTelaListar());

        add(tabbedPane);
        setVisible(true);
    }

    private JPanel criarTelaCadastrar() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("ID Paciente:"), gbc);

        JTextField idPacienteField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(idPacienteField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("ID Profissional:"), gbc);

        JTextField idProfissionalField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(idProfissionalField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Data:"), gbc);

        JTextField dataField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(dataField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Horário:"), gbc);

        JTextField horarioField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(horarioField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Status:"), gbc);

        String[] statusOptions = {"Agendado", "Cancelado", "Concluído"};
        JComboBox<String> statusComboBox = new JComboBox<>(statusOptions);
        statusComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        panel.add(statusComboBox, gbc);

        JButton confirmar = criarBotao("Confirmar");
        JButton cancelar = criarBotao("Cancelar");

        confirmar.addActionListener(e -> {
            try {
                Consulta consulta = new Consulta(
                        Integer.parseInt(idPacienteField.getText()),
                        Integer.parseInt(idProfissionalField.getText()),
                        dataField.getText(),
                        horarioField.getText(),
                        statusComboBox.getSelectedItem().toString()
                );
                new ConsultaController().salvarConsulta(consulta);
                limparCampos(panel);
                JOptionPane.showMessageDialog(this, "Consulta cadastrada com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar consulta: " + ex.getMessage());
            }
        });

        cancelar.addActionListener(e -> dispose());

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        JPanel botaoPanel = new JPanel();
        botaoPanel.add(confirmar);
        botaoPanel.add(cancelar);
        panel.add(botaoPanel, gbc);

        return panel;
    }

    private JPanel criarTelaConsultar() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Digite o ID da consulta:", JLabel.CENTER);
        JTextField idField = new JTextField();

        JButton confirmar = criarBotao("Consultar");
        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                Consulta consulta = new ConsultaController().consultarConsulta(id);
                limparCampos(panel);
                if (consulta != null) {
                    JOptionPane.showMessageDialog(this, formatarConsulta(consulta));
                } else {
                    JOptionPane.showMessageDialog(this, "Consulta não encontrada.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
            }
        });

        panel.add(label);
        panel.add(idField);
        panel.add(confirmar);

        return panel;
    }

    private JPanel criarTelaExcluir() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Digite o ID da consulta:", JLabel.CENTER);
        JTextField idField = new JTextField();

        JButton confirmar = criarBotao("Excluir");
        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                new ConsultaController().excluirConsulta(id);
                limparCampos(panel);
                JOptionPane.showMessageDialog(this, "Consulta excluída com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao excluir consulta: " + ex.getMessage());
            }
        });

        panel.add(label);
        panel.add(idField);
        panel.add(confirmar);

        return panel;
    }

    private JPanel criarTelaListar() {
        JPanel panel = new JPanel(new BorderLayout());

        String[] colunas = {"ID", "ID Paciente", "ID Profissional", "Data", "Horário", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(colunas, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        JButton atualizar = criarBotao("Atualizar Lista");
        atualizar.addActionListener(e -> {
            try {
                List<Consulta> consultas = new ConsultaController().listarConsultas();
                tableModel.setRowCount(0);
                for (Consulta consulta : consultas) {
                    Object[] row = {
                            consulta.getId(),
                            consulta.getIdPaciente(),
                            consulta.getIdProfissional(),
                            consulta.getData(),
                            consulta.getHorario(),
                            consulta.getStatus()
                    };
                    tableModel.addRow(row);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao listar consultas: " + ex.getMessage());
            }
        });

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(atualizar, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel criarTelaAlterar() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("ID da Consulta:"), gbc);

        JTextField idField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("ID Paciente:"), gbc);

        JTextField idPacienteField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(idPacienteField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("ID Profissional:"), gbc);

        JTextField idProfissionalField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(idProfissionalField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Data:"), gbc);

        JTextField dataField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(dataField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Horário:"), gbc);

        JTextField horarioField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(horarioField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("Status:"), gbc);

        String[] statusOptions = {"Agendado", "Cancelado", "Concluído"};
        JComboBox<String> statusComboBox = new JComboBox<>(statusOptions);
        statusComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        panel.add(statusComboBox, gbc);

        JButton confirmar = criarBotao("Alterar");
        JButton cancelar = criarBotao("Cancelar");

        confirmar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                Consulta consulta = new Consulta(
                        Integer.parseInt(idPacienteField.getText()),
                        Integer.parseInt(idProfissionalField.getText()),
                        dataField.getText(),
                        horarioField.getText(),
                        statusComboBox.getSelectedItem().toString()
                );
                consulta.setId(id);
                new ConsultaController().alterarConsulta(consulta);
                limparCampos(panel);
                JOptionPane.showMessageDialog(this, "Consulta alterada com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao alterar consulta: " + ex.getMessage());
            }
        });

        cancelar.addActionListener(e -> dispose());

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        JPanel botaoPanel = new JPanel();
        botaoPanel.add(confirmar);
        botaoPanel.add(cancelar);
        panel.add(botaoPanel, gbc);

        return panel;
    }

    private JButton criarBotao(String texto) {
        JButton botao = new JButton(texto);
        botao.setFocusPainted(false);
        botao.setFont(new Font("Arial", Font.PLAIN, 14));
        botao.setBackground(new Color(70, 130, 180));
        botao.setForeground(Color.WHITE);
        return botao;
    }

    private void limparCampos(JPanel panel) {
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JTextField) {
                ((JTextField) comp).setText("");
            }
        }
    }

    private String formatarConsulta(Consulta consulta) {
        return String.format(
                "ID: %d\nID Paciente: %d\nID Profissional: %d\nData: %s\nHorário: %s\nStatus: %s",
                consulta.getId(), consulta.getIdPaciente(), consulta.getIdProfissional(),
                consulta.getData(), consulta.getHorario(), consulta.getStatus()
        );
    }
}