package Controller;

import Model.Profissional;
import Model.Prontuario;
import dao.ProfissionalDAO;
import dao.ExceptionDAO;

import java.util.List;

public class ProfissionalController {

    private ProfissionalDAO profissionalDAO;

    public ProfissionalController() {
        this.profissionalDAO = new ProfissionalDAO();
    }

    public void salvarProfissional(Profissional profissional) {
        try {
        	new Profissional().salvarProfissional(profissional);
            System.out.println("Profissional salvo com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao salvar profissional: " + e.getMessage());
        }
    }

    public void alterarProfissional(Profissional profissional) {
        try {
            new Profissional().alterarProfissional(profissional);
            System.out.println("Profissional alterado com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao alterar profissional: " + e.getMessage());
        }
    }

    public void excluirProfissional(int id) {
        try {
        	new Profissional().excluirProfissional(id);
            System.out.println("Profissional excluído com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao excluir profissional: " + e.getMessage());
        }
    }

    public List<Profissional> listarProfissionais() {
        try {
            return new Profissional().listarProfissionais();
        } catch (Exception e) {
            System.err.println("Erro ao listar profissionais: " + e.getMessage());
            return null;
        }
    }
}
