package Controller;

import Model.Consulta;
import dao.ConsultaDAO;
import java.util.List;

public class ConsultaController {
    private ConsultaDAO consultaDAO;

    public ConsultaController() {
        this.consultaDAO = new ConsultaDAO();
    }

    public void salvarConsulta(Consulta consulta) {
        try {
            new Consulta().salvarConsulta(consulta);
            System.out.println("Consulta salva com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao salvar consulta: " + e.getMessage());
        }
    }

    public List<Consulta> listarConsultas() {
        try {
            return new Consulta().listarConsultas();
        } catch (Exception e) {
            System.err.println("Erro ao listar consultas: " + e.getMessage());
            return null;
        }
    }

    public void excluirConsulta(int id) {
        try {
        	new Consulta().excluirConsulta(id);
            System.out.println("Consulta excluída com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao excluir consulta: " + e.getMessage());
        }
    }

    public Consulta consultarConsulta(int id) {
        try {
            return new Consulta().consultarConsulta(id);
        } catch (Exception e) {
            System.err.println("Erro ao consultar consulta: " + e.getMessage());
            return null;
        }
    }

    public void alterarConsulta(Consulta consulta) {
        try {
        	new Consulta().alterarConsulta(consulta);
            System.out.println("Consulta alterada com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao alterar consulta: " + e.getMessage());
        }
    }
}
