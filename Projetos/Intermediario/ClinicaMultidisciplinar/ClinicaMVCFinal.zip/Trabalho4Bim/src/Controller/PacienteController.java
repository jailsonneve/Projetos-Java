package Controller;

import Model.Paciente;
import dao.ExceptionDAO;
import dao.PacienteDAO;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class PacienteController {
    private PacienteDAO pacienteDAO;

    public PacienteController() {
        this.pacienteDAO = new PacienteDAO();
    }

    public void salvarPaciente(Paciente paciente) {
        try {
            paciente.salvarPaciente(paciente);
            System.out.println("Paciente salvo com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao salvar paciente: " + e.getMessage());
        }
    }

    public List<Paciente> listarPacientes() {
        try {
            return new Paciente().listarPacientes();
        } catch (Exception e) {
            System.err.println("Erro ao listar pacientes: " + e.getMessage());
            return null;
        }
    }

    public void excluirPaciente(int id) {
        try {
            new Paciente().excluirPaciente(id);
            System.out.println("Paciente excluído com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao excluir paciente: " + e.getMessage());
        }
    }
    
    public void consultarPacientePorId(int id, JFrame tela) {
    	Paciente paciente;
		paciente = new Paciente().consultarPacientePorId(id);
		if (paciente != null) {
		    JOptionPane.showMessageDialog(tela, paciente.getValores());
		} else {
		    JOptionPane.showMessageDialog(tela, "Paciente não encontrado!");
		}
    }
    
    public void alterarPaciente(Paciente paciente, JFrame tela) {
    	try {
            new Paciente().alterarPaciente(paciente);
            JOptionPane.showMessageDialog(tela, "Paciente alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(tela, "Erro ao alterar paciente: " + ex.getMessage());
        }
    }
}