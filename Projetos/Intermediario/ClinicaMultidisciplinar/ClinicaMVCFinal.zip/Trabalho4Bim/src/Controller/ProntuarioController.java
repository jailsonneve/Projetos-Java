// ProntuarioController.java
package Controller;

import Model.Prontuario;
import dao.*;
import java.util.List;

public class ProntuarioController {
    private ProntuarioDAO prontuarioDAO;
    private Prontuario prontuario;

    public ProntuarioController() {
        this.prontuarioDAO = new ProntuarioDAO();
    }

    public void salvarProntuario(Prontuario prontuario) {
        try {
            prontuario.salvarProntuario(prontuario);
            System.out.println("Prontuário salvo com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao salvar prontuário: " + e.getMessage());
        }
    }

    public List<Prontuario> listarProntuarios() {
        try {
            return prontuarioDAO.listarProntuarios();
        } catch (Exception e) {
            System.err.println("Erro ao listar prontuários: " + e.getMessage());
            return null;
        }
    }

    public void excluirProntuario(int id) {
        try {
            prontuarioDAO.excluirProntuario(id);
            System.out.println("Prontuário excluído com sucesso.");
        } catch (Exception e) {
            System.err.println("Erro ao excluir prontuário: " + e.getMessage());
        }
    }
}