// ListaEsperaController.java
package Controller;

import Model.ListaEspera;
import dao.*;
import java.util.List;

public class ListaEsperaController {
    private ListaEsperaDAO listaEsperaDAO;

    public ListaEsperaController() {
        this.listaEsperaDAO = new ListaEsperaDAO();
    }

    public void adicionarNaLista(ListaEspera listaEspera) {
        try {
            new ListaEspera().adicionarNaLista(listaEspera);
            System.out.println("Paciente adicionado à lista de espera.");
        } catch (Exception e) {
            System.err.println("Erro ao adicionar na lista de espera: " + e.getMessage());
        }
    }

    public List<ListaEspera> listarEspera() {
        try {
            return new ListaEspera().listarEspera();
        } catch (Exception e) {
            System.err.println("Erro ao listar a fila de espera: " + e.getMessage());
            return null;
        }
    }

    public void removerDaLista(int id) {
        try {
            new ListaEspera().removerDaLista(id);
            System.out.println("Paciente removido da lista de espera.");
        } catch (Exception e) {
            System.err.println("Erro ao remover da lista de espera: " + e.getMessage());
        }
    }
}